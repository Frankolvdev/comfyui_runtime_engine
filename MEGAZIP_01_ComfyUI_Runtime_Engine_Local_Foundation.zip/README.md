# ComfyUI Runtime Engine — MegaZIP 01

Primera base desacoplada para ejecutar ComfyUI mediante un engine seleccionable.

## Alcance real de esta entrega

- `normal`: inicia el `main.py` de un ComfyUI real como subprocess, sin modificarlo.
- `embedded-simulation`: simula y valida localmente el lifecycle que después usará el modo embebido.
- `doctor`: inspecciona estructura, versión, entrypoint y compatibilidad de ComfyUI.
- Eventos JSONL deterministas para comparar arranques locales y futuros restores.
- Adaptador inicial para ComfyUI `0.15.x`.
- Pruebas unitarias que no requieren GPU, modelos ni Modal.
- Configuración preparada para snapshot y modelos residentes, pero ambas funciones permanecen desactivadas hasta una fase posterior.

Esta entrega no toca el backend, Modal, Beam, RunPod, pipelines ni cancelaciones existentes.

## Instalación local en Windows

Descomprime el ZIP encima del repositorio `comfyui_runtime_engine` (sin carpeta raíz adicional) y ejecuta:

```powershell
cd "C:\ruta\comfyui_runtime_engine"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
Copy-Item runtime-engine.example.toml runtime-engine.toml
```

Edita `runtime-engine.toml` y configura:

```toml
comfyui_path = "C:/Users/frank/OneDrive/Documentos/comfyui-experimental"
```

## Pruebas locales sin iniciar ComfyUI

```powershell
pytest
comfy-runtime --config runtime-engine.toml doctor
comfy-runtime --config runtime-engine.toml simulate
```

La simulación debe terminar con `simulation.completed` y crear:

```text
.runtime/events.jsonl
```

## Inicio normal real

Cuando quieras comprobar que el engine puede arrancar el ComfyUI existente sin alterar su comportamiento:

```powershell
comfy-runtime --config runtime-engine.toml start --mode normal
```

Para detenerlo usa `Ctrl+C`. El engine propaga la terminación al proceso de ComfyUI.

## Modo embedded

En esta primera entrega `embedded` está bloqueado deliberadamente. Solo existe `embedded-simulation`. Esto evita presentar como funcional una integración que todavía no ha sido verificada con el event loop, PromptServer, PromptExecutor y CUDA de ComfyUI 0.15.1.

## Flujo de desarrollo previsto

1. Base local y diagnósticos — esta entrega.
2. Bootstrap embebido de ComfyUI 0.15.1 sin CUDA.
3. Compatibilidad de API, cola, cancelación y apagado.
4. Warmup selectivo y residencia manual de modelos.
5. Snapshot CPU.
6. Snapshot GPU progresivo y validación de restore.
7. Adaptador Modal, sin tocar proveedores ajenos.
